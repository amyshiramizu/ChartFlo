// Chart Scribe → Practice Fusion content script.
// Recognizes SOAP section inputs by label/aria/placeholder/id heuristics and fills them.

const SECTION_KEYS = {
  subjective: [/\bsubjective\b/i, /\bhpi\b/i, /history of present illness/i, /chief complaint/i, /\bcc\b/i, /\bros\b/i, /review of systems/i],
  objective:  [/\bobjective\b/i, /physical exam/i, /\bexam\b/i, /\bvitals?\b/i],
  assessment: [/\bassessment\b/i, /\bdiagnos[ei]s\b/i, /\bimpression\b/i, /\bicd[- ]?10\b/i],
  plan:       [/\bplan\b/i, /\borders?\b/i, /follow[- ]?up/i, /treatment plan/i],
};

function isEditable(el) {
  if (!el) return false;
  const tag = el.tagName;
  if (tag === 'TEXTAREA') return !el.disabled && !el.readOnly;
  if (tag === 'INPUT') {
    const t = (el.type || 'text').toLowerCase();
    return ['text','search',''].includes(t) && !el.disabled && !el.readOnly;
  }
  if (el.isContentEditable) return true;
  return false;
}

function labelTextFor(el) {
  const bits = [];
  if (el.id) {
    const lab = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
    if (lab) bits.push(lab.innerText);
  }
  const wrap = el.closest('label');
  if (wrap) bits.push(wrap.innerText);
  const aria = el.getAttribute('aria-label'); if (aria) bits.push(aria);
  const ph = el.getAttribute('placeholder'); if (ph) bits.push(ph);
  const name = el.getAttribute('name'); if (name) bits.push(name);
  const ttl = el.getAttribute('title'); if (ttl) bits.push(ttl);
  if (el.id) bits.push(el.id);
  // climb up to 4 ancestors for a section heading
  let p = el.parentElement, hops = 0;
  while (p && hops < 4) {
    const heading = p.querySelector('h1,h2,h3,h4,h5,legend,[role="heading"],.section-title,.field-label');
    if (heading && heading.innerText && heading.innerText.length < 80) bits.push(heading.innerText);
    p = p.parentElement; hops++;
  }
  return bits.join(' | ');
}

function classifyEl(el) {
  const text = labelTextFor(el);
  if (!text) return null;
  for (const [key, patterns] of Object.entries(SECTION_KEYS)) {
    if (patterns.some((re) => re.test(text))) return key;
  }
  return null;
}

function collectCandidates() {
  const all = Array.from(document.querySelectorAll('textarea, input, [contenteditable="true"], [contenteditable=""]'));
  const map = {};
  for (const el of all) {
    if (!isEditable(el)) continue;
    const key = classifyEl(el);
    if (!key) continue;
    // prefer textareas / contenteditable over single-line inputs
    const score = el.tagName === 'TEXTAREA' ? 3 : el.isContentEditable ? 2 : 1;
    const prev = map[key];
    if (!prev || score > prev.score) map[key] = { el, score };
  }
  return map;
}

function setValue(el, value) {
  if (el.isContentEditable) {
    el.focus();
    // append a newline if existing content present
    const existing = el.innerText.trim();
    const next = existing ? existing + '\n\n' + value : value;
    el.innerText = next;
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return;
  }
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
  const existing = el.value ? el.value.trim() : '';
  const next = existing ? existing + '\n\n' + value : value;
  setter.call(el, next);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

function flash(el) {
  el.classList.add('cs-pf-flash');
  setTimeout(() => el.classList.remove('cs-pf-flash'), 1200);
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === 'detect') {
    const map = collectCandidates();
    const found = [];
    for (const [key, { el }] of Object.entries(map)) {
      el.classList.add('cs-pf-detected');
      setTimeout(() => el.classList.remove('cs-pf-detected'), 2500);
      found.push(key);
    }
    sendResponse({ found });
    return true;
  }
  if (msg.action === 'push') {
    const res = pushPayload(msg.payload || {});
    sendResponse(res);
    return true;
  }
});

function pushPayload(payload) {
  const map = collectCandidates();
  const filled = [], missed = [];
  for (const [key, value] of Object.entries(payload)) {
    if (!value) continue;
    const target = map[key];
    if (!target) { missed.push(key); continue; }
    try { setValue(target.el, value); flash(target.el); filled.push(key); }
    catch { missed.push(key); }
  }
  return { filled, missed };
}

// ---------- In-page Chart-Notes-style importer ----------
// A floating button that pulls the latest Chart Scribe draft from
// chrome.storage.local (kept current by the web app via background.js)
// and one-click fills the open Practice Fusion SOAP form. Also lets the
// provider insert the live tracked minutes into the Plan section.

(function initImporter() {
  if (window.top !== window.self) return;
  if (!location.hostname.includes('practicefusion.com')) return;
  if (document.getElementById('cs-importer-fab')) return;

  const fab = document.createElement('div');
  fab.id = 'cs-importer-fab';
  fab.className = 'cs-importer-fab';
  fab.innerHTML = `
    <button id="cs-imp-main" class="cs-imp-main" title="Import Chart Scribe note into this encounter">
      <span class="cs-imp-icon">📋</span>
      <span class="cs-imp-label">Import Chart Scribe note</span>
    </button>
    <div id="cs-imp-meta" class="cs-imp-meta">No draft yet</div>
    <div class="cs-imp-actions">
      <button id="cs-imp-minutes" class="cs-imp-mini" title="Append tracked minutes to Plan">+ Minutes</button>
      <button id="cs-imp-refresh" class="cs-imp-mini" title="Refresh draft">↻</button>
      <button id="cs-imp-hide" class="cs-imp-mini" title="Hide">×</button>
    </div>
  `;
  document.body.appendChild(fab);

  const $ = (id) => document.getElementById(id);

  function renderMeta(meta, draft) {
    const el = $('cs-imp-meta');
    if (!el) return;
    if (!draft || !Object.values(draft).some(Boolean)) {
      el.textContent = 'No Chart Scribe draft yet — send a note from the app.';
      return;
    }
    const parts = [];
    if (meta?.patientName) parts.push(meta.patientName);
    if (meta?.mrn) parts.push(`MRN ${meta.mrn}`);
    if (meta?.updatedAt) {
      const t = new Date(meta.updatedAt);
      parts.push(t.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }
    el.textContent = parts.length ? `Ready: ${parts.join(' · ')}` : 'Draft ready';
  }

  function loadAndRender() {
    chrome.storage.local.get(['draft', 'draftMeta'], (d) => {
      renderMeta(d.draftMeta, d.draft);
    });
  }
  loadAndRender();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.draft || changes.draftMeta) loadAndRender();
  });

  $('cs-imp-main').addEventListener('click', () => {
    chrome.storage.local.get(['draft'], (d) => {
      const draft = d.draft || {};
      const payload = {
        subjective: draft.subjective || '',
        objective: draft.objective || '',
        assessment: draft.assessment || '',
        plan: draft.plan || '',
      };
      if (!Object.values(payload).some(Boolean)) {
        toast('No Chart Scribe note to import yet.', true);
        return;
      }
      const res = pushPayload(payload);
      if (res.filled?.length) {
        toast(`Imported: ${res.filled.join(', ')}${res.missed?.length ? ' · missed ' + res.missed.join(', ') : ''}`);
      } else {
        toast('No matching SOAP fields found on this page.', true);
      }
    });
  });

  $('cs-imp-minutes').addEventListener('click', () => {
    chrome.storage.local.get(['csSessionMinutes', 'activePatient'], (d) => {
      const minutes = Number(d.csSessionMinutes?.minutes) || 0;
      if (minutes <= 0) {
        toast('No tracked minutes yet for this session.', true);
        return;
      }
      const map = collectCandidates();
      const target = map.plan || map.assessment;
      if (!target) {
        toast('No Plan/Assessment field to append minutes to.', true);
        return;
      }
      const stamp = new Date().toLocaleDateString();
      const who = d.activePatient?.name ? ` for ${d.activePatient.name}` : '';
      const line = `\n\nTime spent${who}: ${minutes} minute${minutes === 1 ? '' : 's'} of non-face-to-face care coordination on ${stamp} (tracked by Chart Scribe).`;
      try { setValue(target.el, line.trimStart()); flash(target.el); toast(`Added ${minutes} min to Plan.`); }
      catch { toast('Could not append minutes.', true); }
    });
  });

  $('cs-imp-refresh').addEventListener('click', loadAndRender);
  $('cs-imp-hide').addEventListener('click', () => fab.remove());

  function toast(msg, err = false) {
    const t = document.createElement('div');
    t.className = 'cs-imp-toast' + (err ? ' err' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }

  // Keep alive across PF SPA navigations
  const obs = new MutationObserver(() => {
    if (!document.getElementById('cs-importer-fab')) {
      // re-inject by re-running this IIFE
      initImporter();
    }
  });
  obs.observe(document.body, { childList: true, subtree: true });
})();

(function() {
  console.log('CCM Pro Assistant v2.5.18: Content script loaded on', window.location.href);

  // Prevent duplicate message handlers
  if (window.ccmExtensionLoaded) {
    console.log('CCM Extension: Already loaded, skipping');
    return;
  }
  window.ccmExtensionLoaded = true;

  // Listen for messages from the popup
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('CCM Extension: Received message:', request.action);
    
    // Handle ping
    if (request.action === 'ping') {
      sendResponse({ success: true, message: 'Content script is loaded' });
      return true;
    }
    
    // Handle insertText
    if (request.action === 'insertText') {
      console.log('CCM Extension: Handling insertText');
      const result = insertTextIntoActiveElement(request.text);
      sendResponse(result);
      return true;
    }
    
    // Step 1: Search for patient and open their chart
    if (request.action === 'searchPatient') {
      console.log('CCM Extension: === STARTING searchPatient for:', request.patientName);
      searchAndOpenPatient(request.patientName)
        .then(result => {
          console.log('CCM Extension: searchPatient result:', result);
          sendResponse(result);
        })
        .catch(err => {
          console.error('CCM Extension: searchPatient ERROR:', err);
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }
    
    // Combined Steps 2-4: Open CCM encounter, navigate to note, insert text
    if (request.action === 'openAndInsertCCM') {
      console.log('CCM Extension: === STARTING openAndInsertCCM for:', request.patientName);
      openCcmNoteAndInsert(request.text, request.patientName)
        .then(result => {
          console.log('CCM Extension: openAndInsertCCM result:', result);
          sendResponse(result);
        })
        .catch(err => {
          console.error('CCM Extension: openAndInsertCCM ERROR:', err);
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }

    // Chart-type aliases: encounter / med list / TCM / RPM all route through the
    // existing CCM encounter flow for now. The popup prefixes the inserted text
    // with a label like "[Med List Update]" so the note is clearly tagged.
    // TODO: route med_list to the Medications tab and encounter to a fresh
    // encounter note instead of the CCM encounter.
    if (['openAndInsertEncounter', 'openAndInsertMedList', 'openAndInsertTCM', 'openAndInsertRPM'].includes(request.action)) {
      console.log(`CCM Extension: === ${request.action} (chartType=${request.chartType}) for:`, request.patientName);
      openCcmNoteAndInsert(request.text, request.patientName)
        .then(result => sendResponse(result))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    
    // Step 2: Select the current month's CCM encounter (standalone)
    if (request.action === 'openCurrentMonthCCMEncounter') {
      console.log('CCM Extension: === STARTING openCurrentMonthCCMEncounter');
      openCurrentMonthCCMEncounter()
        .then(result => {
          console.log('CCM Extension: openCurrentMonthCCMEncounter result:', result);
          sendResponse(result);
        })
        .catch(err => {
          console.error('CCM Extension: openCurrentMonthCCMEncounter ERROR:', err);
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }
    
    // Step 3: Navigate to the CCM note editor via "Go to..." dropdown
    if (request.action === 'navigateToCCMNote') {
      console.log('CCM Extension: === STARTING navigateToCCMNote');
      navigateToCCMNote()
        .then(result => {
          console.log('CCM Extension: navigateToCCMNote result:', result);
          sendResponse(result);
        })
        .catch(err => {
          console.error('CCM Extension: navigateToCCMNote ERROR:', err);
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }
    
    // Step 4: Insert the narrative text
    if (request.action === 'insertCCMNote') {
      console.log('CCM Extension: === STARTING insertCCMNote');
      insertCCMNoteText(request.text)
        .then(result => {
          console.log('CCM Extension: insertCCMNote result:', result);
          sendResponse(result);
        })
        .catch(err => {
          console.error('CCM Extension: insertCCMNote ERROR:', err);
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }
    
    // Step 5: Save the note
    if (request.action === 'saveCCMNote') {
      console.log('CCM Extension: === STARTING saveCCMNote');
      saveCCMNote()
        .then(result => {
          console.log('CCM Extension: saveCCMNote result:', result);
          sendResponse(result);
        })
        .catch(err => {
          console.error('CCM Extension: saveCCMNote ERROR:', err);
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }
    
    // Step 6: Return to patient list
    if (request.action === 'goBackToCharts') {
      console.log('CCM Extension: === STARTING goBackToCharts');
      goBackToChartsPage()
        .then(result => {
          console.log('CCM Extension: goBackToCharts result:', result);
          sendResponse(result);
        })
        .catch(err => {
          console.error('CCM Extension: goBackToCharts ERROR:', err);
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }
    
    // Clear search input and filters
    if (request.action === 'clearSearch') {
      console.log('CCM Extension: === STARTING clearSearch');
      clearSearchAndFilters()
        .then(() => sendResponse({ success: true }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }
    
    // Get current patient info for detection
    if (request.action === 'getPatientInfo') {
      const info = detectCurrentPatient();
      sendResponse(info);
      return true;
    }
    
    console.log('CCM Extension: Unknown action:', request.action);
    return true;
  });

  // ============================================
  // HELPER FUNCTIONS
  // ============================================

  async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function getCurrentMonthYear() {
    return new Date().toLocaleString('en-US', { month: 'long', year: 'numeric' }).toLowerCase();
  }

  function getCurrentMonthName() {
    return new Date().toLocaleString('en-US', { month: 'long' }).toLowerCase();
  }

  // ============================================
  // PAGE DETECTION FUNCTIONS
  // ============================================

  /**
   * Check if we're on the patient list/charts page
   */
  function isOnPatientListPage() {
    // Check URL patterns
    const url = window.location.href.toLowerCase();
    if (url.includes('/charts/list') || 
        url.includes('/charts/all') ||
        url.includes('/charts/patients') ||  // Added this pattern
        url.includes('charts/list')) {
      return true;
    }
    
    // Check for search input (primary indicator of patient list)
    const searchInput = document.querySelector(
      'input[placeholder*="Search all patients"],' +
      'input[placeholder*="search all patients"],' +
      'input[placeholder*="Search patients"]'
    );
    
    if (searchInput && searchInput.offsetParent !== null) {
      return true;
    }
    
    // Check for "Patient lists" text in the page
    const pageText = document.body.innerText;
    if (pageText.includes('Patient lists') && searchInput) {
      return true;
    }
    
    return false;
  }

  /**
   * Check if we're on an individual patient's chart
   */
  function isOnPatientChartPage() {
    const url = window.location.href.toLowerCase();
    
    // Check for patient chart URL patterns
    if (url.includes('/patient/') || url.includes('/encounter/')) {
      return true;
    }
    
    // Look for patient header elements that indicate we're viewing a specific patient
    const patientHeader = document.querySelector(
      '[class*="patient-demographics"],' +
      '[class*="patient-header"],' +
      '.patient-info-header'
    );
    
    // Also check for PRN number display (patient record number)
    const prnDisplay = document.querySelector('[class*="prn"], [data-element*="prn"]');
    
    if (patientHeader || prnDisplay) {
      // But make sure we're not on the list page
      if (!isOnPatientListPage()) {
        return true;
      }
    }
    
    return false;
  }

  /**
   * Check if we're on a login page
   */
  function isOnLoginPage() {
    // Check URL for login patterns
    const url = window.location.href.toLowerCase();
    if (url.includes('/login') || url.includes('/signin') || url.includes('/auth')) {
      return true;
    }
    
    // Only consider it a login page if there's a visible password field 
    // AND we're NOT on a Practice Fusion app page
    if (url.includes('practicefusion.com/apps/')) {
      // We're in the app, so it's not a login page even if there's a password field somewhere
      return false;
    }
    
    const passwordInput = document.querySelector('input[type="password"]');
    const loginForm = document.querySelector('form[action*="login"], form[action*="Login"]');
    
    // Check if password field is visible and prominent
    if (passwordInput && passwordInput.offsetParent !== null) {
      // Make sure this isn't just a password field in some settings area
      // by checking if the page title or content suggests login
      const pageText = document.body.innerText.toLowerCase();
      if (pageText.includes('sign in') || pageText.includes('log in') || pageText.includes('password')) {
        return true;
      }
    }
    
    if (loginForm) {
      return true;
    }
    
    return false;
  }

  // ============================================
  // NAME MATCHING FUNCTIONS
  // ============================================

  /**
   * Normalize a name for comparison
   */
  function normalizeName(name) {
    if (!name) return '';
    let normalized = name.trim().toUpperCase().replace(/\s+/g, ' ');
    
    // If name is in "LAST, FIRST" format, convert to "FIRST LAST"
    if (normalized.includes(',')) {
      const parts = normalized.split(',').map(p => p.trim());
      if (parts.length >= 2) {
        normalized = parts[1] + ' ' + parts[0];
      }
    }
    return normalized;
  }

  /**
   * Extract name parts
   */
  function getNameParts(name) {
    const normalized = normalizeName(name);
    const parts = normalized.split(' ').filter(p => p.length > 0);
    return {
      full: normalized,
      parts: parts,
      first: parts[0] || '',
      last: parts[parts.length - 1] || '',
      original: name.trim().toUpperCase().split(/[\s,]+/).filter(p => p.length > 0)
    };
  }

  /**
   * Calculate match score between search name and found name
   * IMPROVED: Requires BOTH first AND last name to match for high scores
   */
  function nameMatchScore(searchName, foundName) {
    const search = getNameParts(searchName);
    const found = getNameParts(foundName);
    
    // Skip if found name is too short (like just "L" or initials)
    if (found.full.length < 3) {
      return 0;
    }
    
    let score = 0;
    
    // Exact full match (after normalization)
    if (search.full === found.full) {
      return 100;
    }
    
    // Count how many search parts are found
    let firstNameMatch = false;
    let lastNameMatch = false;
    
    // Check first name
    if (search.first && search.first.length >= 2) {
      for (const foundPart of found.parts) {
        if (foundPart === search.first) {
          firstNameMatch = true;
          score += 40;
          break;
        } else if (foundPart.startsWith(search.first) || search.first.startsWith(foundPart)) {
          // Partial match (e.g., "NORINE" matches "NORIN")
          if (foundPart.length >= 3) {
            firstNameMatch = true;
            score += 30;
            break;
          }
        }
      }
    }
    
    // Check last name
    if (search.last && search.last.length >= 2) {
      for (const foundPart of found.parts) {
        if (foundPart === search.last) {
          lastNameMatch = true;
          score += 40;
          break;
        } else if (foundPart.startsWith(search.last) || search.last.startsWith(foundPart)) {
          if (foundPart.length >= 3) {
            lastNameMatch = true;
            score += 30;
            break;
          }
        }
      }
    }
    
    // CRITICAL: For a good match, we need BOTH first and last name
    // This prevents matching "HEATHER L" when searching for "Heather Lastname"
    if (search.parts.length >= 2 && (!firstNameMatch || !lastNameMatch)) {
      // If we're searching for a full name but only found one part, heavily penalize
      score = Math.min(score, 25);
    }
    
    // Bonus for exact word boundary matches
    if (firstNameMatch && lastNameMatch) {
      score += 20;
    }
    
    return score;
  }

  // ============================================
  // STEP 1: SEARCH FOR PATIENT AND OPEN CHART
  // ============================================

  async function searchAndOpenPatient(patientName) {
    try {
      // Skip if we're in an iframe - only operate on main frame
      if (window !== window.top) {
        console.log('CCM Extension: Skipping - running in iframe, not main frame');
        // Return success to prevent error, but don't do anything
        return { success: false, error: 'Running in iframe - waiting for main frame', isIframe: true };
      }

      console.log('=== STEP 1: Searching for patient ===');
      console.log('Patient name:', patientName);
      console.log('Current URL:', window.location.href);

      // First, check what page we're on
      if (isOnLoginPage()) {
        console.log('ERROR: On login page');
        return { success: false, error: 'On login page - please log in first' };
      }

      // Check if we need to navigate to patient list first
      if (!isOnPatientListPage()) {
        console.log('Not on patient list page, checking if on patient chart...');
        
        if (isOnPatientChartPage()) {
          // Check if this is the CORRECT patient
          const pageText = document.body.innerText.toUpperCase();
          const searchParts = getNameParts(patientName);
          
          const hasFirst = searchParts.first && pageText.includes(searchParts.first);
          const hasLast = searchParts.last && pageText.includes(searchParts.last);
          
          if (hasFirst && hasLast) {
            console.log('Already on correct patient chart');
            return { success: true, message: 'Already on correct patient chart' };
          } else {
            console.log('On wrong patient chart, need to go back to list');
            return { success: false, error: 'On wrong patient chart. Please navigate to Patient Lists first.' };
          }
        }
        
        return { success: false, error: 'Not on Charts page. Please navigate to Patient Lists first.' };
      }

      // Find the search input - with retry/wait
      console.log('Looking for search input...');
      let searchInput = null;
      let searchAttempts = 0;
      const maxSearchAttempts = 10;
      
      while (!searchInput && searchAttempts < maxSearchAttempts) {
        searchAttempts++;
        
        searchInput =
          document.querySelector('input[placeholder*="Search all patients"]') ||
          document.querySelector('input[placeholder*="search all patients"]') ||
          document.querySelector('input[placeholder*="Search patients"]') ||
          document.querySelector('[data-element="patient-search"] input') ||
          document.querySelector('.patient-search-select input');
        
        if (!searchInput) {
          console.log(`Search input not found, waiting... (attempt ${searchAttempts}/${maxSearchAttempts})`);
          await sleep(1000);
        }
      }

      if (!searchInput) {
        console.log('ERROR: Search input not found after waiting');
        return { success: false, error: 'Search input not found - page may not have loaded. Please try again.' };
      }
      
      console.log('Found search input');

      // Clear and focus the input - MUST CLEAR FILTER CHIPS FIRST
      console.log('Clearing search filters...');
      
      // IMPORTANT: Practice Fusion uses filter chips/tags that must be removed
      // The chips look like "Name: Deanna hales ×" with a small × to click
      let clearedCount = 0;
      const maxClearAttempts = 10; // Prevent infinite loops
      let clearAttempt = 0;
      
      // Keep clearing until no more chips are found
      while (clearAttempt < maxClearAttempts) {
        clearAttempt++;
        let foundChipThisRound = false;
        
        try {
          // Method 1: Find chips by looking for "Name:" or "PRN:" text with × buttons
          const allElements = document.querySelectorAll('span, div, button');
          
          for (const el of allElements) {
            const text = (el.textContent || '').trim();
            
            // Look for filter chips that contain "Name:" or "PRN:"
            if ((text.includes('Name:') || text.includes('PRN:')) && text.includes('×')) {
              // Find the × button within this chip
              const closeBtn = el.querySelector('button, [role="button"], span');
              if (closeBtn) {
                const closeBtnText = (closeBtn.textContent || '').trim();
                if (closeBtnText === '×' || closeBtnText === 'x' || closeBtnText === '✕') {
                  console.log('Clicking × in chip:', text.substring(0, 30));
                  closeBtn.click();
                  clearedCount++;
                  foundChipThisRound = true;
                  await sleep(400);
                  break; // Restart the search after clicking
                }
              }
              
              // If no button found, look for the × in the parent
              const parent = el.parentElement;
              if (parent) {
                const btns = parent.querySelectorAll('button, span, svg');
                for (const btn of btns) {
                  const btnText = (btn.textContent || '').trim();
                  if (btnText === '×' || btnText === 'x' || btnText === '✕') {
                    console.log('Clicking × near chip');
                    btn.click();
                    clearedCount++;
                    foundChipThisRound = true;
                    await sleep(400);
                    break;
                  }
                }
                if (foundChipThisRound) break;
              }
            }
          }
          
          // Method 2: Look for standalone × buttons anywhere
          if (!foundChipThisRound) {
            const allButtons = document.querySelectorAll('button, span, div');
            for (const btn of allButtons) {
              const text = (btn.textContent || '').trim();
              if ((text === '×' || text === '✕' || text === 'x') && btn.offsetParent !== null) {
                // Make sure it's near the search area (within reasonable distance)
                const rect = btn.getBoundingClientRect();
                if (rect.top < 400) { // Near top of page where search is
                  const parent = btn.parentElement;
                  const parentText = (parent?.textContent || '').toLowerCase();
                  if (parentText.includes('name') || parentText.includes('prn')) {
                    console.log('Clicking standalone × button');
                    btn.click();
                    clearedCount++;
                    foundChipThisRound = true;
                    await sleep(400);
                    break;
                  }
                }
              }
            }
          }
          
          // Method 3: Look for the ⊗ clear all button (visible in screenshot)
          if (!foundChipThisRound) {
            const clearAllCandidates = document.querySelectorAll('button, span, div, svg');
            for (const el of clearAllCandidates) {
              const text = (el.textContent || '').trim();
              const ariaLabel = (el.getAttribute('aria-label') || '').toLowerCase();
              
              if (text === '⊗' || text.includes('⊗') || 
                  ariaLabel.includes('clear') || ariaLabel.includes('reset')) {
                const rect = el.getBoundingClientRect();
                if (rect.top < 400) { // Near top of page
                  console.log('Clicking ⊗ clear all button');
                  el.click();
                  clearedCount++;
                  foundChipThisRound = true;
                  await sleep(400);
                  break;
                }
              }
            }
          }
          
          // Method 4: Click parent of × if direct click didn't work
          if (!foundChipThisRound) {
            const xButtons = document.querySelectorAll('*');
            for (const el of xButtons) {
              if (el.childNodes.length === 1 && el.childNodes[0].nodeType === 3) {
                const text = el.childNodes[0].textContent.trim();
                if (text === '×' || text === '✕') {
                  const rect = el.getBoundingClientRect();
                  if (rect.top < 400 && rect.top > 0) {
                    console.log('Clicking element containing ×');
                    el.click();
                    clearedCount++;
                    foundChipThisRound = true;
                    await sleep(400);
                    break;
                  }
                }
              }
            }
          }
          
        } catch (e) {
          console.log('Error clearing filters:', e.message);
        }
        
        // If we didn't find any chips this round, we're done
        if (!foundChipThisRound) {
          console.log('No more filter chips found');
          break;
        }
      }
      
      console.log('Cleared', clearedCount, 'filter chips in', clearAttempt, 'attempts');
      await sleep(500);
      
      // Now focus and clear the actual input
      searchInput.focus();
      searchInput.select();
      searchInput.value = '';
      
      // Dispatch events to notify the framework
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      searchInput.dispatchEvent(new Event('change', { bubbles: true }));
      
      // Press Escape to close any dropdowns
      searchInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Escape', code: 'Escape', keyCode: 27 }));
      
      await sleep(500); // Wait for clear to take effect

      // Get name parts - search with full name for best results
      const nameParts = getNameParts(patientName);
      const searchTerm = patientName.trim(); // Use full name
      
      console.log('Typing search term:', searchTerm);
      console.log('Looking for first name:', nameParts.first, 'last name:', nameParts.last);
      
      // Type the search term character by character for better compatibility
      searchInput.value = searchTerm;
      
      // Dispatch multiple events to ensure the search triggers
      // Some frameworks need specific event sequences
      searchInput.dispatchEvent(new Event('focus', { bubbles: true }));
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      searchInput.dispatchEvent(new Event('change', { bubbles: true }));
      
      // Dispatch keydown, keypress, keyup for each key to simulate real typing
      searchInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: searchTerm, code: 'Key' }));
      searchInput.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, key: searchTerm }));
      searchInput.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: searchTerm }));
      
      await sleep(500);
      
      // Now press Enter to submit the search
      console.log('Pressing Enter to search...');
      const enterKeyDown = new KeyboardEvent('keydown', {
        bubbles: true,
        cancelable: true,
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13
      });
      const enterKeyPress = new KeyboardEvent('keypress', {
        bubbles: true,
        cancelable: true,
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13
      });
      const enterKeyUp = new KeyboardEvent('keyup', {
        bubbles: true,
        cancelable: true,
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13
      });
      
      searchInput.dispatchEvent(enterKeyDown);
      searchInput.dispatchEvent(enterKeyPress);
      searchInput.dispatchEvent(enterKeyUp);
      
      // Also try clicking a search button if one exists
      const searchButton = document.querySelector(
        'button[type="submit"], ' +
        'button[aria-label*="search"], ' +
        'button[aria-label*="Search"], ' +
        '.search-button, ' +
        '[data-element*="search"] button'
      );
      if (searchButton) {
        console.log('Found search button, clicking...');
        searchButton.click();
      }

      // Wait for results to filter
      console.log('Waiting for search results...');
      await sleep(3000);

      // Find the best matching patient
      console.log('Looking for patient matches...');
      
      const candidates = [];
      // nameParts already declared above
      
      // Method 1: Check table rows FIRST - look at the full row text
      // This handles cases where first and last name are in separate elements
      const rows = document.querySelectorAll('tbody tr, .charts-list-results tr, tr.ember-view');
      console.log('Table rows found:', rows.length);
      
      for (const row of rows) {
        // Get the FULL row text to check for both first and last name
        const rowText = row.textContent.toUpperCase();
        
        // Check if this row contains BOTH the first name AND last name
        const hasFirst = nameParts.first && rowText.includes(nameParts.first);
        const hasLast = nameParts.last && rowText.includes(nameParts.last);
        
        if (hasFirst && hasLast) {
          console.log('Found row with both names:', rowText.substring(0, 80));
          
          // Find a clickable element in this row (the name link)
          const clickable = row.querySelector(
            'div.text-color-link, ' +
            'a.text-color-link, ' +
            '.text-color-link, ' +
            '[data-element="patient-first-name"]'
          );
          
          if (clickable && clickable.offsetParent !== null) {
            // Give high score since we found both names in the row
            candidates.push({ 
              element: clickable, 
              text: clickable.textContent.trim(), 
              score: 100, // High score for row match
              type: 'rowMatch'
            });
          }
        }
      }
      
      // Method 2: Look for individual patient name divs (fallback)
      if (candidates.length === 0) {
        const patientNameDivs = document.querySelectorAll(
          'div.text-color-link, ' +
          '[data-element="patient-first-name"], ' +
          '[data-element*="patient-name"], ' +
          '.chart-list-results__col_patient-name div, ' +
          '.patient-name, ' +
          'td div.text-color-link'
        );
        
        console.log('Patient name elements found:', patientNameDivs.length);
        
        for (const div of patientNameDivs) {
          const text = div.textContent.trim();
          if (text.length < 3 || text.length > 100) continue;
          if (/^\d+\/\d+\/\d+$/.test(text)) continue;
          if (/^\d+$/.test(text)) continue;
          
          const score = nameMatchScore(patientName, text);
          if (score > 0) {
            candidates.push({ element: div, text: text, score: score, type: 'nameDiv' });
          }
        }
      }
      
      // Remove duplicates and sort by score
      const uniqueCandidates = [];
      const seenElements = new Set();
      for (const c of candidates) {
        if (!seenElements.has(c.element)) {
          seenElements.add(c.element);
          uniqueCandidates.push(c);
        }
      }
      uniqueCandidates.sort((a, b) => b.score - a.score);
      
      console.log('Unique candidates found:', uniqueCandidates.length);
      uniqueCandidates.slice(0, 5).forEach((c, i) => {
        console.log(`  ${i + 1}. Score: ${c.score}, Text: "${c.text}", Type: ${c.type}`);
      });
      
      // Click if we have a match (score >= 60 for individual elements, or any rowMatch)
      if (uniqueCandidates.length > 0 && uniqueCandidates[0].score >= 60) {
        const best = uniqueCandidates[0];
        console.log('=== CLICKING BEST MATCH ===');
        console.log('Text:', best.text, 'Score:', best.score);
        
        best.element.click();
        await sleep(3000);
        
        console.log('SUCCESS: Clicked patient name, chart should be opening');
        return { success: true };
      }
      
      // If no high-confidence match, try searching by last name only
      if (uniqueCandidates.length === 0 || uniqueCandidates[0].score < 60) {
        console.log('No confident match found, trying last name search...');
        
        // Clear the search properly
        searchInput.focus();
        searchInput.value = '';
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
        searchInput.dispatchEvent(new Event('change', { bubbles: true }));
        
        // Press Enter to clear
        searchInput.dispatchEvent(new KeyboardEvent('keydown', {
          bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13
        }));
        await sleep(1000);
        
        // Search by last name
        const lastName = nameParts.last;
        console.log('Searching by last name:', lastName);
        searchInput.value = lastName;
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
        searchInput.dispatchEvent(new Event('change', { bubbles: true }));
        
        // Press Enter to search
        searchInput.dispatchEvent(new KeyboardEvent('keydown', {
          bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13
        }));
        searchInput.dispatchEvent(new KeyboardEvent('keyup', {
          bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13
        }));
        
        await sleep(3000);
        
        // Look again using row-based matching
        console.log('Checking rows after last name search...');
        const retryRows = document.querySelectorAll('tbody tr, .charts-list-results tr, tr.ember-view');
        
        for (const row of retryRows) {
          const rowText = row.textContent.toUpperCase();
          const hasFirst = nameParts.first && rowText.includes(nameParts.first);
          const hasLast = nameParts.last && rowText.includes(nameParts.last);
          
          if (hasFirst && hasLast) {
            console.log('Found row match on retry:', rowText.substring(0, 60));
            
            const clickable = row.querySelector(
              'div.text-color-link, a.text-color-link, .text-color-link, [data-element="patient-first-name"]'
            );
            
            if (clickable && clickable.offsetParent !== null) {
              console.log('Clicking:', clickable.textContent.trim());
              clickable.click();
              await sleep(3000);
              return { success: true };
            }
          }
        }
        
        // Final fallback - check individual divs
        const retryDivs = document.querySelectorAll('div.text-color-link, .text-color-link');
        
        for (const div of retryDivs) {
          const text = div.textContent.trim();
          const score = nameMatchScore(patientName, text);
          
          console.log(`  Retry div check: "${text}" score: ${score}`);
          
          if (score >= 60) {
            console.log('Found match on retry:', text);
            div.click();
            await sleep(3000);
            return { success: true };
          }
        }
      }

      console.log('ERROR: Patient not found:', patientName);
      console.log('Please verify:');
      console.log('  1. The patient name spelling matches exactly');
      console.log('  2. The patient exists in Practice Fusion');
      console.log('  3. You are on the correct patient list view');
      
      return { 
        success: false, 
        error: `Patient not found: "${patientName}". Please verify the name matches the chart exactly.`
      };
      
    } catch (e) {
      console.error('Search error:', e);
      return { success: false, error: e.message };
    }
  }

  // ============================================
  // COMBINED STEP 2-4: Open CCM, Navigate to Note, Insert Text
  // ============================================

  async function openCcmNoteAndInsert(narrative, expectedPatientName) {
    console.log('=== STEPS 2-4: Opening CCM visit, navigating to note, inserting text ===');
    console.log('Expected patient:', expectedPatientName);

    const now = new Date();
    const monthName = now.toLocaleString('en-US', { month: 'long' }).toLowerCase();
    const shortMonth = now.toLocaleString('en-US', { month: 'short' }).toLowerCase();
    const monthNum = String(now.getMonth() + 1).padStart(2, '0');
    console.log('Looking for CCM with:', monthName, 'or', shortMonth, 'or', monthNum);

    // STEP 2: Wait for the patient chart to load
    console.log('Step 2: Waiting for patient chart to load...');
    
    let correctPatient = false;
    let attempts = 0;
    const maxAttempts = 15;
    
    while (attempts < maxAttempts && !correctPatient) {
      attempts++;
      await sleep(1000);
      
      const pageText = document.body.innerText.toUpperCase();
      const expectedParts = getNameParts(expectedPatientName);
      
      const hasFirstName = expectedParts.first && pageText.includes(expectedParts.first);
      const hasLastName = expectedParts.last && pageText.includes(expectedParts.last);
      
      if (hasFirstName && hasLastName) {
        correctPatient = true;
        console.log('Patient chart verified:', expectedPatientName);
      }
    }
    
    if (!correctPatient) {
      console.log('ERROR: Could not verify patient chart loaded for', expectedPatientName);
      return { success: false, error: 'Could not verify patient chart loaded for ' + expectedPatientName };
    }
    
    // Make sure we're on the Timeline tab to see encounters
    console.log('Ensuring Timeline tab is selected...');
    const allTabs = document.querySelectorAll('a, button, [role="tab"]');
    for (const tab of allTabs) {
      const tabText = (tab.textContent || '').trim().toLowerCase();
      if (tabText === 'timeline') {
        console.log('Found Timeline tab, clicking...');
        tab.click();
        await sleep(2000);
        break;
      }
    }
    
    // Look for CCM encounters
    console.log('Looking for CCM encounters...');
    await sleep(2000);
    
    // Current month info
    const currentYear = now.getFullYear().toString();
    
    let ccmRowFound = false;
    
    // Method 1: Find all clickable "Office Visit" or "Home Visit" links
    const allLinks = document.querySelectorAll('a');
    console.log('Total links found:', allLinks.length);
    console.log('Looking for CCM with month:', monthName, shortMonth, monthNum + '/' + currentYear);
    
    // Log first few links for debugging
    let linkCount = 0;
    for (const link of allLinks) {
      const linkText = link.textContent.toLowerCase().trim();
      if (linkCount < 5) {
        console.log('Sample link:', linkText.substring(0, 30));
        linkCount++;
      }
      
      // Check if this is a visit type link - be more flexible
      if (linkText.includes('visit') || linkText.includes('office') || linkText.includes('home')) {
        // Check the surrounding row/container for CCM and current month
        const row = link.closest('tr') || link.closest('[class*="row"]') || link.parentElement?.parentElement;
        
        if (row) {
          const rowText = row.textContent.toLowerCase();
          
          const hasCCM = rowText.includes('ccm');
          const hasCurrentMonth = rowText.includes(monthName) || 
                                  rowText.includes(shortMonth + ' ' + currentYear) || 
                                  rowText.includes(shortMonth + currentYear) ||
                                  rowText.includes(monthNum + '/' + currentYear) ||
                                  rowText.includes(monthNum + '/01/' + currentYear);
          
          console.log('Checking visit link:', linkText.substring(0, 20), '| hasCCM:', hasCCM, '| hasCurrentMonth:', hasCurrentMonth);
          
          if (hasCCM && hasCurrentMonth) {
            console.log('=== FOUND CURRENT MONTH CCM ROW VIA METHOD 1 ===');
            console.log('Row text:', rowText.substring(0, 150));
            console.log('Clicking link:', link.textContent.trim());
            
            link.click();
            ccmRowFound = true;
            await sleep(4000);
            break;
          }
        }
      }
    }
    
    // Calculate previous month for exclusion (used in multiple methods)
    const prevMonth = now.getMonth() === 0 ? 11 : now.getMonth() - 1;
    const prevMonthNum = String(prevMonth + 1).padStart(2, '0');
    const prevMonthName = new Date(now.getFullYear(), prevMonth, 1).toLocaleString('en-US', { month: 'long' }).toLowerCase();
    const prevShortMonth = new Date(now.getFullYear(), prevMonth, 1).toLocaleString('en-US', { month: 'short' }).toLowerCase();
    
    // Method 2: If no link found, try finding by row content
    if (!ccmRowFound) {
      console.log('Method 1 failed, trying Method 2...');
      
      try {
        // Look for table rows specifically
        const rows = document.querySelectorAll('tr');
        console.log('Found', rows.length, 'table rows');
        
        for (const row of rows) {
          const rowText = (row.textContent || '').toLowerCase();
          
          // Check for CCM (Complex CCM or just CCM)
          const hasCCM = rowText.includes('complex ccm') || 
                         (rowText.includes('ccm') && !rowText.includes('rpm'));
          
          // Check for current month
          const hasCurrentMonth = rowText.includes(monthName) || 
                                  rowText.includes(shortMonth + ' ' + currentYear) ||
                                  rowText.includes(shortMonth + currentYear) ||
                                  rowText.includes(monthNum + '/01/' + currentYear) ||
                                  rowText.includes(monthNum + '/' + currentYear) ||
                                  (rowText.includes(monthNum + '/') && rowText.includes(currentYear));
          
          // Exclude previous months
          const hasOtherMonth = rowText.includes(prevMonthName) || 
                                rowText.includes(prevShortMonth + ' ') ||
                                rowText.includes(prevMonthNum + '/');
          
          if (hasCCM && hasCurrentMonth && !hasOtherMonth) {
            console.log('=== Found current month CCM row ===');
            console.log('Row text:', rowText.substring(0, 200));
            
            // Find the Office Visit or Home Visit link in this row
            const anchors = row.querySelectorAll('a');
            console.log('Anchors in row:', anchors.length);
            
            let anchor = null;
            
            // List all anchors for debugging
            for (let i = 0; i < anchors.length; i++) {
              const a = anchors[i];
              const aText = (a.textContent || '').trim();
              console.log('  Anchor', i, ':', aText);
              
              if (aText.toLowerCase().includes('visit') || 
                  aText.toLowerCase().includes('office') ||
                  aText.toLowerCase().includes('home')) {
                anchor = a;
                console.log('  >>> This is the visit link!');
              }
            }
            
            // If no visit anchor found, use the first anchor
            if (!anchor && anchors.length > 0) {
              anchor = anchors[0];
              console.log('Using first anchor as fallback');
            }
            
            if (anchor) {
              console.log('>>> Clicking anchor:', anchor.textContent.trim());
              
              anchor.scrollIntoView({ behavior: 'instant', block: 'center' });
              await sleep(500);
              
              // Try multiple click methods
              anchor.focus();
              anchor.click();
              console.log('>>> Click executed');
              
              // Also dispatch click event
              anchor.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
              console.log('>>> Click event dispatched');
              
              ccmRowFound = true;
              await sleep(5000);
              console.log('>>> Wait complete');
              break;
            } else {
              console.log('WARNING: No anchor found in row!');
              
              // Try finding any clickable element
              const clickables = row.querySelectorAll('a, button, [role="button"], [class*="link"]');
              console.log('Other clickables:', clickables.length);
              
              if (clickables.length > 0) {
                const el = clickables[0];
                console.log('Clicking first clickable:', el.textContent.trim());
                el.scrollIntoView({ behavior: 'instant', block: 'center' });
                await sleep(500);
                el.click();
                ccmRowFound = true;
                await sleep(5000);
                break;
              } else {
                // Try clicking the row itself
                console.log('Clicking row itself...');
                row.click();
                ccmRowFound = true;
                await sleep(5000);
                break;
              }
            }
          }
        }
        
        // If still not found, try a more aggressive search
        if (!ccmRowFound) {
          console.log('Row search failed, trying text-based search...');
          
          // Find all Office Visit / Home Visit links
          const visitLinks = document.querySelectorAll('a');
          
          for (const link of visitLinks) {
            const linkText = (link.textContent || '').toLowerCase().trim();
            
            if (linkText === 'office visit' || linkText === 'home visit') {
              // Check the entire row by looking at sibling cells
              const row = link.closest('tr');
              if (row) {
                const rowText = row.textContent.toLowerCase();
                
                // Check if this row has CCM and current month date
                if (rowText.includes('ccm') && 
                    (rowText.includes(shortMonth) || rowText.includes(monthNum + '/'))) {
                  
                  // Make sure it's not a different month
                  if (!rowText.includes(prevShortMonth) && !rowText.includes(prevMonthNum + '/')) {
                    
                    console.log('=== Found via text search ===');
                    console.log('Link:', linkText);
                    console.log('Row text:', rowText.substring(0, 150));
                    
                    link.scrollIntoView({ behavior: 'instant', block: 'center' });
                    await sleep(500);
                    link.click();
                    
                    ccmRowFound = true;
                    await sleep(5000);
                    break;
                  }
                }
              }
            }
          }
        }
        
      } catch (method2Err) {
        console.error('Method 2 error:', method2Err.message);
      }
    }
    
    // Method 3: Just find any element containing "Office Visit" near current month and "CCM"
    if (!ccmRowFound) {
      console.log('Method 2 failed, trying Method 3 - direct text search...');
      
      // Find all text that mentions current month and CCM
      const bodyText = document.body.innerHTML.toLowerCase();
      
      if ((bodyText.includes(monthName) || bodyText.includes(shortMonth)) && bodyText.includes('ccm')) {
        console.log('Page contains current month CCM reference');
        
        // Find Office Visit links
        const officeVisitLinks = Array.from(document.querySelectorAll('a')).filter(a => 
          a.textContent.toLowerCase().includes('office visit')
        );
        
        console.log('Office Visit links found:', officeVisitLinks.length);
        
        // Click the first one that's near CCM current month text
        for (const link of officeVisitLinks) {
          const parent = link.closest('tr') || link.closest('div');
          if (parent) {
            const parentText = parent.textContent.toLowerCase();
            if (parentText.includes('ccm') && (parentText.includes(monthName) || parentText.includes(shortMonth))) {
              console.log('Found via Method 3, clicking:', link.textContent);
              link.click();
              ccmRowFound = true;
              await sleep(4000);
              break;
            }
          }
        }
      }
    }
    
    if (!ccmRowFound) {
      console.log('ERROR: Patient does not have a CCM note for', monthName);
      return { success: false, error: 'Patient does not have a CCM note for ' + monthName };
    }
    
    // STEP 3: Navigate to the CCM note
    console.log('Step 3: Opening CCM note editor...');
    const navResult = await navigateToCCMNote();
    if (!navResult || !navResult.success) {
      console.error('Failed to navigate to CCM note:', navResult?.error);
      return { success: false, error: 'Unable to open CCM note editor' };
    }
    console.log('SUCCESS: Opened CCM note editor');

    // STEP 4: Insert the narrative
    console.log('Step 4: Inserting narrative...');
    const insertResult = await insertCCMNoteText(narrative);
    if (!insertResult || !insertResult.success) {
      console.error('Failed to insert narrative:', insertResult?.error);
      return { success: false, error: 'Unable to insert text' };
    }
    console.log('SUCCESS: Narrative inserted into note');
    
    return { success: true };
  }

  // ============================================
  // STEP 2: Open CCM Encounter (standalone)
  // ============================================

  async function openCurrentMonthCCMEncounter() {
    try {
      console.log('=== STEP 2: Opening current month CCM visit note ===');
      
      const monthYear = getCurrentMonthYear();
      const monthName = getCurrentMonthName();
      const year = new Date().getFullYear().toString();
      console.log('Looking for CCM note with:', monthName, year);

      const rows = document.querySelectorAll('tr');
      console.log('Table rows found:', rows.length);

      for (const row of rows) {
        const rowText = row.textContent.toLowerCase();
        
        if (rowText.includes('ccm') && 
            (rowText.includes(monthName) || rowText.includes(monthYear))) {
          
          console.log('=== FOUND CURRENT MONTH CCM ROW ===');
          
          const visitLink = row.querySelector('a');
          
          if (visitLink) {
            console.log('Clicking visit link:', visitLink.textContent.trim());
            visitLink.click();
            await sleep(3000);
            return { success: true };
          }
        }
      }

      // Fallback: Look for any unsigned CCM
      console.log('Looking for any unsigned CCM...');
      for (const row of rows) {
        const rowText = row.textContent.toLowerCase();
        
        if (rowText.includes('ccm') && 
            !rowText.includes('signed') &&
            rowText.includes(year)) {
          
          const visitLink = row.querySelector('a');
          
          if (visitLink) {
            console.log('Clicking visit link:', visitLink.textContent.trim());
            visitLink.click();
            await sleep(3000);
            return { success: true };
          }
        }
      }

      return { success: false, error: 'CCM visit note not found' };
      
    } catch (e) {
      console.error('Step 2 error:', e);
      return { success: false, error: e.message };
    }
  }

  // ============================================
  // STEP 3: NAVIGATE TO CCM NOTE
  // ============================================

  async function navigateToCCMNote() {
    try {
      console.log('=== STEP 3: Verifying CCM note page ===');
      
      // Wait for encounter page to fully load
      await sleep(4000);
      
      // After clicking Office Visit, the note editor should already be visible
      // We just need to verify we're on the right page - DO NOT CLICK ANYTHING
      
      // Check if "Total CCM Time" marker exists on page (means we're in CCM note)
      console.log('Checking for Total CCM Time marker...');
      const pageText = document.body.innerText;
      
      if (pageText.includes('Total CCM Time')) {
        console.log('Found Total CCM Time marker - we are on the CCM note page');
        return { success: true };
      }
      
      // Check for other CCM indicators
      if (pageText.includes('Chronic Care Management') || pageText.includes('CCM Conditions')) {
        console.log('Found CCM content - we are on the CCM note page');
        return { success: true };
      }
      
      // Check if there's a rich text editor visible
      console.log('Looking for rich text editor...');
      const editor = document.querySelector(
        '[contenteditable="true"], ' +
        'textarea:not([hidden]), ' +
        'iframe[class*="wysihtml"], ' +
        '.wysihtml5-editor'
      );
      
      if (editor && editor.offsetParent !== null) {
        console.log('Found visible editor element');
        return { success: true };
      }
      
      // Wait a bit more and check again
      console.log('Waiting for page to load...');
      await sleep(3000);
      
      // Check again for CCM content
      const pageTextRetry = document.body.innerText;
      if (pageTextRetry.includes('Total CCM Time') || 
          pageTextRetry.includes('Chronic Care Management') ||
          pageTextRetry.includes('CCM Conditions')) {
        console.log('Found CCM content after waiting');
        return { success: true };
      }
      
      // At this point, assume we're on the right page
      // The insertCCMNoteText function will handle finding the editor
      console.log('Proceeding to insert text...');
      return { success: true };
      
    } catch (e) {
      console.error('Step 3 error:', e);
      return { success: false, error: e.message };
    }
  }

  // ============================================
  // STEP 4: INSERT TEXT INTO CCM NOTE
  // ============================================

  async function insertCCMNoteText(text) {
    try {
      console.log('=== STEP 4: Inserting note text ===');
      console.log('Text length:', text.length);

      // Wait for the note editor to load
      console.log('Waiting for note editor to load...');
      await sleep(3000);
      
      // Try to find the editor with retries
      let retryCount = 0;
      const maxRetries = 5;
      
      while (retryCount < maxRetries) {
        retryCount++;
        console.log(`Looking for editor (attempt ${retryCount}/${maxRetries})...`);

        // Method 1: Look for the "Total CCM Time" text and insert before it
        console.log('Looking for Total CCM Time marker...');
        const pageText = document.body.innerText;
        
        if (pageText.includes('Total CCM Time')) {
          console.log('Found "Total CCM Time" marker on page');
          
          // Find all contenteditable areas and editable divs
          const editableAreas = document.querySelectorAll(
            '[contenteditable="true"], ' +
            '.note-editable, ' +
            '[class*="editor"], ' +
            '[class*="note-content"], ' +
            '[role="textbox"]'
          );
          
          console.log('Found', editableAreas.length, 'editable areas');
          
          for (const editable of editableAreas) {
            const editableText = editable.innerText || editable.textContent;
            
            if (editableText.includes('Total CCM Time')) {
              console.log('Found editor with Total CCM Time marker');
              editable.focus();
              
              // Find the exact text node containing "Total CCM Time"
              const walker = document.createTreeWalker(
                editable,
                NodeFilter.SHOW_TEXT,
                null,
                false
              );
              
              let node;
              while (node = walker.nextNode()) {
                if (node.textContent.includes('Total CCM Time')) {
                  console.log('Found Total CCM Time text node');
                  
                  // Get the parent element (likely a div or p)
                  let targetElement = node.parentElement;
                  console.log('Target element tag:', targetElement.tagName);
                  console.log('Target parent tag:', targetElement.parentNode?.tagName);
                  
                  // Create new paragraph with the text
                  const newPara = document.createElement('p');
                  newPara.innerHTML = text.replace(/\n/g, '<br>');
                  console.log('Created paragraph with text length:', newPara.innerHTML.length);
                  
                  // Add a line break before the marker
                  const spacer = document.createElement('br');
                  
                  // Insert before the Total CCM Time element
                  targetElement.parentNode.insertBefore(newPara, targetElement);
                  targetElement.parentNode.insertBefore(spacer, targetElement);
                  
                  console.log('Inserted paragraph. New editor content length:', editable.innerHTML.length);
                  
                  // Trigger multiple events to ensure the framework picks up the change
                  editable.dispatchEvent(new Event('input', { bubbles: true }));
                  editable.dispatchEvent(new Event('change', { bubbles: true }));
                  editable.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
                  
                  // Also try focusing and blurring to trigger any validation
                  editable.focus();
                  await sleep(100);
                  editable.blur();
                  await sleep(100);
                  editable.focus();
                  
                  console.log('SUCCESS: Text inserted before Total CCM Time');
                  console.log('Verification - editor now contains text:', editable.innerText.includes(text.substring(0, 50)) ? 'YES' : 'NO');
                  return { success: true };
                }
              }
            }
          }
        }

        // Method 2: Find any rich text editor by looking for toolbar nearby
        console.log('Looking for rich text editor...');
        const toolbars = document.querySelectorAll('[class*="toolbar"], [class*="editor-toolbar"], [role="toolbar"]');
        
        for (const toolbar of toolbars) {
          // Look for contenteditable near the toolbar
          const parent = toolbar.parentElement;
          if (parent) {
            const editor = parent.querySelector('[contenteditable="true"], [class*="editable"]');
            if (editor && editor.offsetParent !== null) {
              console.log('Found editor near toolbar');
              editor.focus();
              
              // Try to insert at cursor or end
              const selection = window.getSelection();
              if (selection) {
                const range = selection.getRangeAt(0);
                const textNode = document.createTextNode(text + '\n\n');
                range.insertNode(textNode);
                editor.dispatchEvent(new Event('input', { bubbles: true }));
                console.log('SUCCESS: Text inserted at cursor');
                return { success: true };
              }
              
              // Append at end
              editor.innerHTML += '<br><br>' + text.replace(/\n/g, '<br>');
              editor.dispatchEvent(new Event('input', { bubbles: true }));
              console.log('SUCCESS: Text appended to editor');
              return { success: true };
            }
          }
        }

        // Method 3: wysihtml5 iframe editor
        console.log('Looking for wysihtml5 editor...');
        const wysihtml5Iframe = document.querySelector('iframe.wysihtml5-sandbox, iframe[class*="wysihtml"]');
        
        if (wysihtml5Iframe) {
          console.log('Found wysihtml5 iframe');
          try {
            const iframeDoc = wysihtml5Iframe.contentDocument || wysihtml5Iframe.contentWindow.document;
            const editorBody = iframeDoc.body;
            
            if (editorBody && editorBody.innerHTML.length > 0) {
              editorBody.focus();
              
              const bodyText = editorBody.innerText || editorBody.textContent;
              
              if (bodyText.includes('Total CCM Time')) {
                console.log('Found "Total CCM Time" marker in iframe');
                
                const walker = document.createTreeWalker(
                  editorBody,
                  NodeFilter.SHOW_TEXT,
                  null,
                  false
                );
                
                let node;
                while (node = walker.nextNode()) {
                  if (node.textContent.includes('Total CCM Time')) {
                    let targetElement = node.parentElement;
                    
                    const newPara = iframeDoc.createElement('p');
                    newPara.innerHTML = text.replace(/\n/g, '<br>');
                    
                    const spacer = iframeDoc.createElement('p');
                    spacer.innerHTML = '<br>';
                    
                    targetElement.parentNode.insertBefore(newPara, targetElement);
                    targetElement.parentNode.insertBefore(spacer, targetElement);
                    
                    editorBody.dispatchEvent(new Event('input', { bubbles: true }));
                    
                    console.log('SUCCESS: Text inserted before Total CCM Time in iframe');
                    return { success: true };
                  }
                }
              }
              
              // Append at end
              const newPara = iframeDoc.createElement('p');
              newPara.innerHTML = text.replace(/\n/g, '<br>');
              editorBody.appendChild(iframeDoc.createElement('br'));
              editorBody.appendChild(newPara);
              editorBody.dispatchEvent(new Event('input', { bubbles: true }));
              console.log('SUCCESS: Text appended to iframe editor');
              return { success: true };
            }
          } catch (iframeError) {
            console.error('Iframe access error:', iframeError);
          }
        }

        // Method 4: Textarea
        console.log('Looking for textarea...');
        const textareas = document.querySelectorAll('textarea');
        
        for (const textarea of textareas) {
          if (textarea.offsetParent !== null && !textarea.disabled && !textarea.readOnly) {
            console.log('Found textarea:', textarea.name || textarea.id || 'unnamed');
            
            const content = textarea.value;
            const markerIndex = content.indexOf('Total CCM Time');
            
            if (markerIndex !== -1) {
              const before = content.substring(0, markerIndex);
              const after = content.substring(markerIndex);
              textarea.value = before + text + '\n\n' + after;
            } else {
              textarea.value = content + '\n\n' + text;
            }
            
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
            textarea.dispatchEvent(new Event('change', { bubbles: true }));
            console.log('SUCCESS: Text inserted into textarea');
            return { success: true };
          }
        }

        // Method 5: Any contenteditable
        console.log('Looking for any contenteditable...');
        const editables = document.querySelectorAll('[contenteditable="true"]');
        
        for (const editable of editables) {
          if (editable.offsetParent !== null && editable.innerText.length > 50) {
            console.log('Found large contenteditable element');
            editable.focus();
            
            // Append at end
            editable.innerHTML += '<br><br>' + text.replace(/\n/g, '<br>');
            editable.dispatchEvent(new Event('input', { bubbles: true }));
            console.log('SUCCESS: Text appended to contenteditable');
            return { success: true };
          }
        }
        
        // If editor not found, wait and retry
        console.log('Editor not found, waiting 2 seconds before retry...');
        await sleep(2000);
      }

      console.log('ERROR: Could not find note editor after all retries');
      return { success: false, error: 'Could not find note editor' };
      
    } catch (e) {
      console.error('Step 4 error:', e);
      return { success: false, error: e.message };
    }
  }

  // ============================================
  // STEP 5: SAVE THE NOTE
  // ============================================

  async function saveCCMNote() {
    try {
      console.log('=== STEP 5: Saving note ===');
      
      const buttons = document.querySelectorAll('button, input[type="button"], input[type="submit"], a.btn');
      
      for (const btn of buttons) {
        const label = (btn.textContent || btn.value || '').trim().toLowerCase();
        
        if (label === 'save' || label.startsWith('save')) {
          if (btn.offsetParent !== null && !btn.disabled) {
            console.log('Clicking Save:', label);
            btn.click();
            await sleep(2500);
            return { success: true };
          }
        }
      }
      
      const saveBtn = document.querySelector('[data-element*="save"], .save-button, .btn-save');
      if (saveBtn && saveBtn.offsetParent !== null) {
        saveBtn.click();
        await sleep(2500);
        return { success: true };
      }
      
      console.log('WARNING: Save button not found');
      return { success: false, error: 'Save button not found' };
      
    } catch (e) {
      console.error('Save error:', e);
      return { success: false, error: e.message };
    }
  }

  // ============================================
  // STEP 6: RETURN TO PATIENT LIST
  // ============================================

  async function goBackToChartsPage() {
    try {
      console.log('=== STEP 6: Returning to patient list ===');
      
      // Check if we're on login page
      if (isOnLoginPage()) {
        console.log('ERROR: On login page - session may have expired');
        return { success: false, error: 'Session expired - please log in again' };
      }
      
      // Handle any "Leave site?" or confirmation dialogs
      await handleLeaveDialog();
      
      // Try clicking "Patient lists" link first (more reliable than direct URL)
      const patientListsLink = document.querySelector('a[href*="charts/list"], [data-element*="patient-list"]');
      if (patientListsLink) {
        console.log('Clicking Patient lists link');
        patientListsLink.click();
        await sleep(2000);
        await handleLeaveDialog();
        return { success: true };
      }
      
      // Navigate to charts page via URL
      const chartsUrl = 'https://static.practicefusion.com/apps/ehr/index.html#/PF/charts/list/all/recent';
      console.log('Navigating to charts page...');
      window.location.href = chartsUrl;
      
      // Wait and handle any dialogs that appear
      await sleep(1000);
      await handleLeaveDialog();
      await sleep(2000);
      
      return { success: true };
      
    } catch (e) {
      console.error('Go back error:', e);
      return { success: false, error: e.message };
    }
  }

  /**
   * Handle "Leave site?" and other confirmation dialogs
   */
  async function handleLeaveDialog() {
    try {
      // Look for "Leave" or "OK" or "Continue" buttons in dialogs
      const dialogButtons = document.querySelectorAll(
        '[class*="modal"] button, ' +
        '[class*="dialog"] button, ' +
        '[role="dialog"] button, ' +
        '.modal button, ' +
        '.dialog button'
      );
      
      for (const btn of dialogButtons) {
        const text = (btn.textContent || '').trim().toLowerCase();
        
        if (text === 'leave' || text === 'ok' || text === 'continue' || 
            text === 'yes' || text === 'confirm' || text === "don't save") {
          console.log('Clicking dialog button:', text);
          btn.click();
          await sleep(500);
          return;
        }
      }
      
      // Look for Leave button by iterating through buttons
      const allButtons = document.querySelectorAll('button');
      for (const btn of allButtons) {
        const text = (btn.textContent || '').trim().toLowerCase();
        if (text === 'leave') {
          btn.click();
          await sleep(500);
          break;
        }
      }
      
    } catch (e) {
      console.log('No dialog to handle or error:', e.message);
    }
  }

  // ============================================
  // MANUAL TEXT INSERTION
  // ============================================

  function insertTextIntoActiveElement(text) {
    const active = document.activeElement;
    
    if (active && active.tagName === 'TEXTAREA') {
      const cursorPos = active.selectionStart;
      const content = active.value;
      
      if (cursorPos !== undefined && cursorPos >= 0) {
        const before = content.substring(0, cursorPos);
        const after = content.substring(cursorPos);
        active.value = before + text + after;
        const newPos = cursorPos + text.length;
        active.setSelectionRange(newPos, newPos);
      } else {
        active.value = content + '\n\n' + text;
      }
      
      active.dispatchEvent(new Event('input', { bubbles: true }));
      active.dispatchEvent(new Event('change', { bubbles: true }));
      return { success: true };
    }
    
    if (active && (active.isContentEditable || active.contentEditable === 'true')) {
      document.execCommand('insertText', false, text);
      active.dispatchEvent(new Event('input', { bubbles: true }));
      return { success: true };
    }
    
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        if (iframeDoc.body && iframeDoc.body.isContentEditable) {
          iframeDoc.body.focus();
          iframeDoc.execCommand('insertText', false, text);
          return { success: true };
        }
      } catch (e) {}
    }
    
    return { success: false };
  }

  // ============================================
  // SEARCH CLEARING FUNCTION
  // ============================================

  async function clearSearchAndFilters() {
    console.log('CCM Extension: Clearing search and filters...');
    
    // Clear filter chips first
    let clearedCount = 0;
    const maxClearAttempts = 10;
    let clearAttempt = 0;
    
    while (clearAttempt < maxClearAttempts) {
      clearAttempt++;
      let foundChipThisRound = false;
      
      try {
        const allElements = document.querySelectorAll('span, div, button');
        
        for (const el of allElements) {
          const text = (el.textContent || '').trim();
          
          if ((text.includes('Name:') || text.includes('PRN:')) && (text.includes('×') || text.includes('✕'))) {
            const closeBtn = el.querySelector('button, [role="button"], span');
            if (closeBtn) {
              const closeBtnText = (closeBtn.textContent || '').trim();
              if (closeBtnText === '×' || closeBtnText === 'x' || closeBtnText === '✕') {
                console.log('CCM Extension: Clearing chip:', text.substring(0, 30));
                closeBtn.click();
                clearedCount++;
                foundChipThisRound = true;
                await sleep(400);
                break;
              }
            }
          }
        }
      } catch (e) {
        console.log('Error clearing filters:', e.message);
      }
      
      if (!foundChipThisRound) break;
    }
    
    // Clear the search input
    const searchInput = document.querySelector(
      'input[placeholder*="Search all patients"],' +
      'input[placeholder*="search all patients"],' +
      'input[placeholder*="Search patients"]'
    );
    
    if (searchInput) {
      searchInput.focus();
      searchInput.value = '';
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      searchInput.dispatchEvent(new Event('change', { bubbles: true }));
      searchInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Escape', code: 'Escape', keyCode: 27 }));
    }
    
    console.log('CCM Extension: Cleared', clearedCount, 'filter chips');
    return { success: true };
  }

  // ============================================
  // PATIENT DETECTION FUNCTION
  // ============================================

  function detectCurrentPatient() {
    const url = window.location.href;
    const isPracticeFusion = url.includes('practicefusion.com');
    const isPatientList = isOnPatientListPage();
    const isPatientChart = isOnPatientChartPage();
    
    let patientName = null;
    
    if (isPatientChart) {
      // Try to extract patient name from the page
      const patientHeader = document.querySelector(
        '[class*="patient-demographics"],' +
        '[class*="patient-header"],' +
        '.patient-info-header'
      );
      
      if (patientHeader) {
        patientName = patientHeader.textContent.trim().split('\n')[0];
      }
    }
    
    return {
      isPracticeFusion,
      isPatientList,
      isPatientChart,
      patientName,
      url
    };
  }

})();
